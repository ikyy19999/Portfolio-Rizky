import React, {
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
} from "react";
import { flushSync } from "react-dom";
import PropTypes from "prop-types";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import ScrollSmoother from "gsap/ScrollSmoother";
import { useGSAP } from "@gsap/react";

import Header from "./components/Header";
import Hero from "./components/Hero";
import About from "./components/About";
import Skill from "./components/Skill";
import Work from "./components/Work";
import Reviews from "./components/Reviews";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import CursorFollower from "./components/CursorFollower";
import ImmersiveScene from "./components/ImmersiveScene";
import CommandPalette from "./components/CommandPalette";
import GotoShortcuts from "./components/GotoShortcuts";
import MotionWatchdog from "./components/MotionWatchdog";
import WhatsNew from "./components/WhatsNew";
import ProjectCaseStudy from "./components/ProjectCaseStudy";
import { useLanguage } from "./context/LanguageContext";
import {
  isReducedMotion,
  subscribeToMotion,
} from "./lib/motionPreference";
import {
  CURRENT_UPDATE_VERSION,
  WHATS_NEW_STORAGE_KEY,
} from "./data/updates";

gsap.registerPlugin(ScrollTrigger, ScrollSmoother, useGSAP);

const getInitialTheme = () => {
  if (typeof window === "undefined") {
    return "light";
  }

  const savedTheme = window.localStorage.getItem("portfolio-theme");

  if (savedTheme === "light" || savedTheme === "dark") {
    return savedTheme;
  }

  return window.matchMedia("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light";
};

const getJavaneseGreeting = (hour) => {
  if (hour >= 4 && hour < 11) {
    return "sugeng enjing";
  }

  if (hour >= 11 && hour < 15) {
    return "sugeng siyang";
  }

  if (hour >= 15 && hour < 18) {
    return "sugeng sonten";
  }

  return "sugeng dalu";
};

const HandwritingIntro = ({ onComplete }) => {
  const { copy, language } = useLanguage();
  const [fontReady, setFontReady] = useState(false);
  const [deviceHour] = useState(() => new Date().getHours());
  const introWord =
    language === "jv"
      ? getJavaneseGreeting(deviceHour)
      : copy.intro.word;

  useEffect(() => {
    let active = true;

    const fontTimeout = window.setTimeout(() => {
      if (active) {
        setFontReady(true);
      }
    }, 2500);

    const loadFont = async () => {
      try {
        if (document.fonts) {
          await document.fonts.load('1em "Birthstone"');
        }
      } finally {
        if (active) {
          setFontReady(true);
        }
      }
    };

    loadFont();

    return () => {
      active = false;

      window.clearTimeout(fontTimeout);
    };
  }, []);

  useEffect(() => {
    if (!fontReady) {
      return undefined;
    }

    const timer = window.setTimeout(onComplete, 4300);

    return () => {
      window.clearTimeout(timer);
    };
  }, [fontReady, onComplete]);

  return (
    <div
      className={`intro-screen ${fontReady ? "is-ready" : ""}`}
      role="status"
      aria-label={`${introWord}, ${copy.intro.welcome}`}
    >
      <div className="intro-word-wrap" aria-hidden="true">
        <span
          className={`intro-word ${language === "jv" ? "is-long" : ""}`}
        >
          {introWord}
        </span>

        <span className="intro-pen" />
      </div>

      <p className="intro-caption">{copy.intro.caption}</p>
    </div>
  );
};

HandwritingIntro.propTypes = {
  onComplete: PropTypes.func.isRequired,
};

const languageTransitionMessages = {
  en: {
    eyebrow: "switching language",
    title: "one sec, switching to english.",
    description: "hang tight, we're getting everything ready.",
  },
  id: {
    eyebrow: "ganti bahasa",
    title: "bentar ya, lagi siapin bahasa indonesia.",
    description: "biar semuanya lebih enak dibaca.",
  },
  jv: {
    eyebrow: "nggantos basa",
    title: "sekedhap nggih, basa jawi saweg dipunsiapaken.",
    description: "supados sedaya langkung trep dipunwaos.",
  },
};

const LanguageTransitionOverlay = () => {
  const { languageTransition } = useLanguage();
  const [imageFailed, setImageFailed] = useState(false);
  const targetLanguage = languageTransition.targetLanguage ?? "en";
  const message = languageTransitionMessages[targetLanguage];

  return (
    <div
      className={`language-transition-overlay ${
        languageTransition.active ? "is-active" : ""
      } is-${languageTransition.phase}`}
      aria-hidden={!languageTransition.active}
    >
      <div className="language-transition-backdrop" aria-hidden="true" />

      <div
        className="language-transition-panel"
        role="status"
        aria-live="polite"
        aria-atomic="true"
      >
        <div className="language-transition-visual" aria-hidden="true">
          {imageFailed ? (
            <span className="material-symbols-rounded">translate</span>
          ) : (
            <img
              src="/assets/illustrations/language-transition.svg"
              alt=""
              onError={() => setImageFailed(true)}
            />
          )}
        </div>

        <p className="language-transition-eyebrow">{message.eyebrow}</p>
        <p className="language-transition-title">{message.title}</p>
        <p className="language-transition-description">
          {message.description}
        </p>

        <span className="language-transition-progress" aria-hidden="true">
          <span />
        </span>
      </div>
    </div>
  );
};

const App = () => {
  const { language, isLanguageTransitioning } = useLanguage();
  const [theme, setTheme] = useState(getInitialTheme);
  const themeTransitionRef = useRef(false);
  const [showIntro, setShowIntro] = useState(true);
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [whatsNewOpen, setWhatsNewOpen] = useState(false);
  const [caseStudySlug, setCaseStudySlug] = useState(null);
  const [reduceMotion, setReduceMotion] = useState(isReducedMotion);
  const [hasUnreadUpdates, setHasUnreadUpdates] = useState(() => {
    if (typeof window === "undefined") {
      return false;
    }

    return (
      window.localStorage.getItem(WHATS_NEW_STORAGE_KEY) !==
      CURRENT_UPDATE_VERSION
    );
  });
  const scrollLocked =
    showIntro ||
    isLanguageTransitioning ||
    commandPaletteOpen ||
    whatsNewOpen ||
    Boolean(caseStudySlug);

  const completeIntro = useCallback(() => {
    setShowIntro(false);
  }, []);

  const openCommandPalette = useCallback(() => {
    setWhatsNewOpen(false);
    setCommandPaletteOpen(true);
  }, []);

  const closeCommandPalette = useCallback(() => {
    setCommandPaletteOpen(false);
  }, []);

  const openWhatsNew = useCallback(() => {
    setCommandPaletteOpen(false);
    setWhatsNewOpen(true);
    setHasUnreadUpdates(false);
    window.localStorage.setItem(
      WHATS_NEW_STORAGE_KEY,
      CURRENT_UPDATE_VERSION,
    );
  }, []);

  const closeWhatsNew = useCallback(() => {
    setWhatsNewOpen(false);
  }, []);

  const openCaseStudy = useCallback((slug) => {
    setCommandPaletteOpen(false);
    setWhatsNewOpen(false);
    setCaseStudySlug(slug);
  }, []);

  const closeCaseStudy = useCallback(() => {
    setCaseStudySlug(null);
  }, []);

  useLayoutEffect(() => {
    document.documentElement.dataset.theme = theme;

    document.documentElement.style.colorScheme = theme;

    window.localStorage.setItem("portfolio-theme", theme);
  }, [theme]);

  useEffect(() => {
    return subscribeToMotion(() => {
      setReduceMotion(isReducedMotion());
    });
  }, []);

  useLayoutEffect(() => {
    const root = document.documentElement;
    const previousSmoother = ScrollSmoother.get();

    previousSmoother?.kill();

    if (reduceMotion) {
      root.dataset.scrollSmoother = "native";
      ScrollTrigger.refresh();
      return undefined;
    }

    root.dataset.scrollSmoother = "active";

    const smoother = ScrollSmoother.create({
      wrapper: "#smooth-wrapper",
      content: "#smooth-content",
      smooth: 1.15,
      smoothTouch: 0.12,
      effects: true,
      ignoreMobileResize: true,
      normalizeScroll: false,
    });

    const refreshFrame = window.requestAnimationFrame(() => {
      ScrollTrigger.refresh();
    });

    return () => {
      window.cancelAnimationFrame(refreshFrame);
      smoother.kill();
      root.dataset.scrollSmoother = "native";
    };
  }, [reduceMotion]);

  useEffect(() => {
    const smoother = ScrollSmoother.get();

    if (!smoother) return undefined;

    smoother.paused(scrollLocked);

    return () => {
      if (ScrollSmoother.get() === smoother) {
        smoother.paused(false);
      }
    };
  }, [reduceMotion, scrollLocked]);

  useEffect(() => {
    document.body.classList.toggle("intro-active", showIntro);

    return () => {
      document.body.classList.remove("intro-active");
    };
  }, [showIntro]);

  useEffect(() => {
    const handleCommandShortcut = (event) => {
      const isCommandShortcut =
        (event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k";

      if (!isCommandShortcut) return;

      event.preventDefault();

      if (showIntro || isLanguageTransitioning) return;

      setWhatsNewOpen(false);
      setCommandPaletteOpen((currentValue) => !currentValue);
    };

    document.addEventListener("keydown", handleCommandShortcut);

    return () => {
      document.removeEventListener("keydown", handleCommandShortcut);
    };
  }, [isLanguageTransitioning, showIntro]);

  useGSAP(() => {
    const elements = gsap.utils.toArray(".reveal-up");

    elements.forEach((element) => {
      gsap.to(element, {
        y: 0,
        opacity: 1,
        ease: "power2.out",
        scrollTrigger: {
          trigger: element,
          start: "top 92%",
          end: "top 65%",
          scrub: 0.6,
        },
      });
    });
  }, []);

  useEffect(() => {
    if (showIntro) {
      return undefined;
    }

    const refreshFrame = window.requestAnimationFrame(() => {
      ScrollTrigger.refresh();
    });

    return () => {
      window.cancelAnimationFrame(refreshFrame);
    };
  }, [language, showIntro]);

  const toggleTheme = useCallback(
    async ({ x, y } = {}) => {
      if (themeTransitionRef.current) {
        return Promise.resolve();
      }

      const nextTheme = theme === "dark" ? "light" : "dark";
      const reduceMotion = isReducedMotion();
      const canUseViewTransition =
        typeof document.startViewTransition === "function";

      if (reduceMotion) {
        setTheme(nextTheme);
        return;
      }

      const originX = typeof x === "number" ? x : window.innerWidth / 2;
      const originY = typeof y === "number" ? y : window.innerHeight / 2;
      const radius = Math.hypot(
        Math.max(originX, window.innerWidth - originX),
        Math.max(originY, window.innerHeight - originY),
      );
      const root = document.documentElement;

      themeTransitionRef.current = true;

      root.style.setProperty("--theme-transition-x", `${originX}px`);
      root.style.setProperty("--theme-transition-y", `${originY}px`);
      root.style.setProperty("--theme-transition-radius", `${radius}px`);

      if (!canUseViewTransition) {
        root.classList.add("theme-fallback-out");

        await new Promise((resolve) => {
          window.setTimeout(resolve, 180);
        });

        flushSync(() => {
          setTheme(nextTheme);
        });

        root.classList.remove("theme-fallback-out");
        root.classList.add("theme-fallback-in");

        await new Promise((resolve) => {
          window.setTimeout(resolve, 320);
        });

        root.classList.remove("theme-fallback-in");
        root.style.removeProperty("--theme-transition-x");
        root.style.removeProperty("--theme-transition-y");
        root.style.removeProperty("--theme-transition-radius");
        themeTransitionRef.current = false;

        return;
      }

      root.classList.add("theme-transitioning");

      const transition = document.startViewTransition(() => {
        flushSync(() => {
          setTheme(nextTheme);
        });
      });

      await transition.finished.finally(() => {
        themeTransitionRef.current = false;
        root.classList.remove("theme-transitioning");
        root.style.removeProperty("--theme-transition-x");
        root.style.removeProperty("--theme-transition-y");
        root.style.removeProperty("--theme-transition-radius");
      });
    },
    [theme],
  );

  return (
    <>
      {showIntro && <HandwritingIntro onComplete={completeIntro} />}

      <LanguageTransitionOverlay />

      <div className={`site-shell ${showIntro ? "is-loading" : "is-ready"}`}>
        {/* <CursorFollower /> */}

        <ImmersiveScene />

        <Header
          theme={theme}
          onToggleTheme={toggleTheme}
          onOpenCommandPalette={openCommandPalette}
        />

        <div id="smooth-wrapper">
          <div id="smooth-content">
            <main>
              <Hero />
              <About />
              <Skill />
              <Work onOpenCaseStudy={openCaseStudy} />
              <Reviews />
              <Contact />
            </main>

            <Footer
              hasUnreadUpdates={hasUnreadUpdates}
              onOpenWhatsNew={openWhatsNew}
            />
          </div>
        </div>
      </div>

      <CommandPalette
        open={commandPaletteOpen}
        theme={theme}
        hasUnreadUpdates={hasUnreadUpdates}
        onClose={closeCommandPalette}
        onOpenWhatsNew={openWhatsNew}
        onOpenCaseStudy={openCaseStudy}
        onToggleTheme={toggleTheme}
      />

      <WhatsNew open={whatsNewOpen} onClose={closeWhatsNew} />

      <ProjectCaseStudy slug={caseStudySlug} onClose={closeCaseStudy} />

      <MotionWatchdog enabled={!showIntro} />

      <GotoShortcuts
        disabled={
          showIntro ||
          isLanguageTransitioning ||
          commandPaletteOpen ||
          whatsNewOpen ||
          Boolean(caseStudySlug)
        }
      />
    </>
  );
};

export default App;
